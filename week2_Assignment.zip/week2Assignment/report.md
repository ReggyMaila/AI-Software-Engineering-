Title: CO2Cast — Short-term Forecasting of National CO₂ Emissions (SDG13)
Problem: Governments need near-term forecasts of CO₂ emissions to monitor progress and design interventions. Historical emissions plus economic and energy indicators can predict short-term changes.
Approach: Supervised regression. Features: current-year CO₂, lagged CO₂, GDP, population, energy use, renewables share. Models tested: Linear Regression (baseline) and Random Forest (main).
Dataset: Merged World Bank and Our World in Data country-year indicators (1990–2022). Data preprocessing included lag feature creation, missing-value handling, and scaling. Train/test split: years < 2015 train; ≥2015 test.
Results: Random Forest outperformed linear baseline on test set: MAE ≈ X (example) vs baseline MAE ≈ Y. (Replace X/Y with your run values). Feature importance shows that previous-year CO₂ and energy use were top predictors.
Ethical Considerations: Data gaps bias predictions for low-income countries with poor reporting. Model may be misused to understate responsibility if not audited. We must ensure transparency, communicate uncertainty, and avoid automated policy decisions without expert review.
Deliverables: Jupyter notebook with annotated code, trained model artifact, README with instructions, 5-minute demo slides and a short video demo (optional).
Impact: Short-term forecasts can help target policy and monitoring; combined with emission scenario modelling they support SDG13 planning.
