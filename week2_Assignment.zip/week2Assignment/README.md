# CO2Cast — SDG13: Forecasting CO₂ Emissions (Starter Repo)

## Overview
CO2Cast is a prototype ML project that forecasts next-year national CO₂ emissions using historical emissions and socio-economic indicators.

## Files
- `co2cast_starter.py` - starter script (also notebook-ready)
- `data/` - (place your CSV files here)
- `artifacts/` - saved model & scaler (created after running)
- `README.md`
- `report.md` - 1-page summary
- `slides/` - presentation (optional)

## How to run (Google Colab / Local)
1. Install dependencies:

