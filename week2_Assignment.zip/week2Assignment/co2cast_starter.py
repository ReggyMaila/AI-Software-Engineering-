# co2cast_starter.py  -- runnable script / notebook cells
import pandas as pd
import numpy as np
from sklearn.model_selection import TimeSeriesSplit, train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import joblib
import os

# --- 1. Load data -----------------------------------------------------------
# Replace these paths with your downloaded CSVs (World Bank / Our World in Data)
# Example expected merged dataframe columns: ['country','year','co2','gdp','population','energy_use','renewables_pct']
df_co2 = pd.read_csv('data/co2_by_country.csv')         # contains 'country','year','co2'
df_gdp = pd.read_csv('data/gdp_by_country.csv')         # contains 'country','year','gdp'
df_pop = pd.read_csv('data/population_by_country.csv')  # contains 'country','year','population'
df_energy = pd.read_csv('data/energy_by_country.csv')   # contains 'country','year','energy_use','renewables_pct'

# Merge on country & year
dfs = [df_co2, df_gdp, df_pop, df_energy]
df = dfs[0]
for other in dfs[1:]:
    df = df.merge(other, on=['country','year'], how='left')

# --- 2. Basic cleaning -----------------------------------------------------
# Keep recent years only (example)
df = df[df['year'] >= 1990].copy()

# Sort
df = df.sort_values(['country','year']).reset_index(drop=True)

# Create lag features: co2_t-1, co2_t-2
df['co2_lag1'] = df.groupby('country')['co2'].shift(1)
df['co2_lag2'] = df.groupby('country')['co2'].shift(2)

# Drop rows where target or key features are missing
df = df.dropna(subset=['co2','gdp','population','energy_use','co2_lag1'])

# Define prediction target: predict co2 for next year
df['co2_next'] = df.groupby('country')['co2'].shift(-1)

# Drop until co2_next available
df = df.dropna(subset=['co2_next']).copy()

# --- 3. Feature + target ---------------------------------------------------
features = ['co2','co2_lag1','co2_lag2','gdp','population','energy_use','renewables_pct']
X = df[features].fillna(0)
y = df['co2_next'].astype(float)

# Simple train/test split: use years < 2015 for training, >=2015 for testing (time-aware)
train_mask = df['year'] < 2015
X_train, X_test = X[train_mask], X[~train_mask]
y_train, y_test = y[train_mask], y[~train_mask]

# Standardize numeric features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# --- 4. Models --------------------------------------------------------------
# Baseline: Linear Regression
lr = LinearRegression()
lr.fit(X_train_scaled, y_train)
y_pred_lr = lr.predict(X_test_scaled)

# Random Forest
rf = RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1)
rf.fit(X_train, y_train)  # RF handles unscaled features fine
y_pred_rf = rf.predict(X_test)

# --- 5. Evaluation ---------------------------------------------------------
def eval_model(y_true, y_pred, name='Model'):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    print(f"{name} -> MAE: {mae:.3f}, RMSE: {rmse:.3f}, R2: {r2:.3f}")
    return {'mae':mae,'rmse':rmse,'r2':r2}

metrics_lr = eval_model(y_test, y_pred_lr, 'LinearRegression')
metrics_rf = eval_model(y_test, y_pred_rf, 'RandomForest')

# --- 6. Visualize actual vs predicted for test set -------------------------
plt.figure(figsize=(10,6))
plt.scatter(y_test, y_pred_rf, alpha=0.6)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'k--', lw=2)
plt.xlabel('Actual CO2 (next year)')
plt.ylabel('Predicted CO2 (next year)')
plt.title('Random Forest: Actual vs Predicted')
plt.grid(True)
plt.tight_layout()
plt.show()

# Show sample country-level prediction over time for a country
sample_country = 'South Africa'  # change as needed
mask = df['country'] == sample_country
if mask.sum() > 0:
    times = df.loc[mask, 'year']
    actual_next = df.loc[mask, 'co2_next']
    # For demonstration, we need to predict for the rows present in X_test that match sample_country
    match_idx = mask & (~train_mask)
    if match_idx.sum() > 0:
        preds = rf.predict(X.loc[match_idx])
        plt.figure(figsize=(10,4))
        plt.plot(times.loc[match_idx], actual_next.loc[match_idx], label='Actual (next)')
        plt.plot(times.loc[match_idx], preds, label='Predicted', linestyle='--')
        plt.xlabel('Year')
        plt.ylabel('CO2 (metric tons)')
        plt.title(f'{sample_country}: Actual vs Predicted CO2')
        plt.legend()
        plt.grid(True)
        plt.show()

# --- 7. Save model and scaler ----------------------------------------------
os.makedirs('artifacts', exist_ok=True)
joblib.dump(rf, 'artifacts/rf_co2_model.joblib')
joblib.dump(scaler, 'artifacts/scaler.joblib')
print("Saved model and scaler to artifacts/")

# --- 8. Quick feature importance -------------------------------------------
importances = rf.feature_importances_
for feat, imp in sorted(zip(features, importances), key=lambda x: x[1], reverse=True):
    print(f"{feat}: {imp:.3f}")

# End of starter script

